'use client';
import { useState, useRef, useEffect } from 'react';

const PIN = process.env.NEXT_PUBLIC_BROWSE_PIN || '1234';
const SK  = 'pb_ok';

// ── Styles ─────────────────────────────────────────────────────────────────────
const G = `
  *,*::before,*::after{box-sizing:border-box;margin:0;padding:0;}
  :root{
    --bg:#111213;--s1:#1c1d1f;--s2:#242628;--br:#2e3032;
    --ac:#8b5cf6;--adim:#5b3fa6;--ag:rgba(139,92,246,.18);
    --tx:#e8e9ea;--mu:#7a7d82;
    --mono:'Courier New',monospace;--sans:system-ui,-apple-system,sans-serif;
  }
  html,body{height:100%;background:var(--bg);color:var(--tx);font-family:var(--sans);}
  ::selection{background:var(--ac);color:#fff;}
  @keyframes shake{0%,100%{transform:translateX(0)}25%,75%{transform:translateX(-8px)}50%{transform:translateX(8px)}}
  @keyframes float{0%,100%{transform:translateY(0)}50%{transform:translateY(-7px)}}
  @keyframes fadein{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:translateY(0)}}
`;

// ── Icon SVGs ──────────────────────────────────────────────────────────────────
function Hat() {
  return (
    <svg width="80" height="80" viewBox="0 0 80 80" fill="none">
      <ellipse cx="40" cy="35" rx="33" ry="8" fill="#3a3c42"/>
      <rect x="21" y="10" width="38" height="27" rx="5" fill="#3a3c42"/>
      <rect x="21" y="28" width="38" height="7" fill="#27292e"/>
      <ellipse cx="40" cy="55" rx="19" ry="16" fill="#4a4d56"/>
      <rect x="15" y="49" width="20" height="13" rx="6" fill="#111213" stroke="#8b5cf6" strokeWidth="2"/>
      <rect x="45" y="49" width="20" height="13" rx="6" fill="#111213" stroke="#8b5cf6" strokeWidth="2"/>
      <line x1="35" y1="55" x2="45" y2="55" stroke="#8b5cf6" strokeWidth="2"/>
      <circle cx="25" cy="55" r="3.5" fill="#8b5cf6" opacity=".8"/>
      <circle cx="55" cy="55" r="3.5" fill="#8b5cf6" opacity=".8"/>
    </svg>
  );
}

// ── PIN Gate ───────────────────────────────────────────────────────────────────
function PinGate({ onUnlock }) {
  const [digits, setDigits] = useState(['','','','']);
  const [shake, setShake]   = useState(false);
  const [err, setErr]       = useState('');
  const refs = [useRef(), useRef(), useRef(), useRef()];

  useEffect(() => { refs[0].current?.focus(); }, []);

  function attempt(pin) {
    if (pin === PIN) {
      try { sessionStorage.setItem(SK,'1'); } catch {}
      onUnlock();
    } else {
      setShake(true); setErr('Incorrect PIN');
      setDigits(['','','','']);
      setTimeout(() => { setShake(false); setErr(''); refs[0].current?.focus(); }, 700);
    }
  }

  function onInput(i, e) {
    const v = e.target.value.replace(/\D/g,'').slice(-1);
    const next = [...digits]; next[i] = v; setDigits(next);
    if (v && i < 3) refs[i+1].current?.focus();
    if (next.every(d => d)) attempt(next.join(''));
  }

  function onKeyDown(i, e) {
    if (e.key === 'Backspace' && !digits[i] && i > 0) refs[i-1].current?.focus();
  }

  return (
    <div style={{minHeight:'100dvh',display:'flex',alignItems:'center',justifyContent:'center',background:'var(--bg)'}}>
      <style>{G}</style>
      <div style={{textAlign:'center',animation:'fadein .4s ease'}}>
        <div style={{marginBottom:28,display:'inline-block',animation:'float 4s ease-in-out infinite',filter:'drop-shadow(0 0 20px rgba(139,92,246,.4))'}}>
          <Hat/>
        </div>
        <p style={{color:'var(--mu)',fontSize:12,letterSpacing:'.1em',marginBottom:28}}>ENTER PIN TO CONTINUE</p>
        <div style={{display:'flex',gap:12,justifyContent:'center',marginBottom:14,animation:shake?'shake .5s ease':'none'}}>
          {digits.map((d,i) => (
            <input key={i} ref={refs[i]} type="password" inputMode="numeric" maxLength={1} value={d}
              onChange={e => onInput(i,e)} onKeyDown={e => onKeyDown(i,e)}
              style={{width:54,height:62,textAlign:'center',fontSize:26,fontWeight:700,
                background:'var(--s1)',border:`2px solid ${d?'var(--ac)':'var(--br)'}`,
                borderRadius:12,color:'var(--tx)',outline:'none',
                boxShadow:d?'0 0 0 3px var(--ag)':'none',transition:'all .15s'}}/>
          ))}
        </div>
        <p style={{fontSize:12,color:'#ef4444',height:18,opacity:err?1:0}}>{err||' '}</p>
      </div>
    </div>
  );
}

// ── New Tab Page ───────────────────────────────────────────────────────────────
const QUICK = [
  ['DuckDuckGo',  'https://lite.duckduckgo.com/lite/'],
  ['Wikipedia',   'https://en.wikipedia.org'],
  ['Hacker News', 'https://news.ycombinator.com'],
  ['GitHub',      'https://github.com'],
  ['BBC News',    'https://bbc.co.uk/news'],
  ['YouTube',     'https://youtube.com'],
];

const BULLETS = [
  'Every request is made from the server — your IP never reaches the target site.',
  'No history, cookies or session data is stored anywhere.',
  'Tracking scripts and fingerprinting see only the server.',
  'Close the tab and every trace is gone.',
];

function NewTab() {
  const [q, setQ] = useState('');
  const inputRef  = useRef();
  useEffect(() => { inputRef.current?.focus(); }, []);

  function go(raw) {
    let url = raw.trim();
    if (!url) return;
    if (url.includes(' ') || !url.includes('.')) {
      url = 'https://lite.duckduckgo.com/lite/?q=' + encodeURIComponent(url);
    } else if (!/^https?:\/\//i.test(url)) {
      url = 'https://' + url;
    }
    window.location.href = '/api/proxy?url=' + encodeURIComponent(url);
  }

  function onKey(e) { if (e.key === 'Enter') go(q); }

  return (
    <div style={{minHeight:'100dvh',background:'var(--bg)',color:'var(--tx)',fontFamily:'var(--sans)',overflowY:'auto'}}>
      <style>{G}{`
        .ql{padding:10px 16px;background:var(--s1);border:1px solid var(--br);border-radius:10px;
          color:var(--mu);font-size:13px;font-weight:500;cursor:pointer;transition:all .15s;text-align:center;}
        .ql:hover{border-color:var(--ac);color:var(--ac);background:var(--ag);}
        .pc{background:var(--s1);border:1px solid var(--br);border-radius:12px;padding:14px 16px;
          font-size:13px;color:var(--mu);line-height:1.55;display:flex;gap:10px;align-items:flex-start;transition:all .2s;}
        .pc:hover{border-color:var(--adim);background:var(--s2);}
      `}</style>

      <div style={{maxWidth:680,margin:'0 auto',padding:'60px 24px 80px'}}>
        {/* Icon + title */}
        <div style={{textAlign:'center',marginBottom:40}}>
          <div style={{display:'inline-block',marginBottom:20,animation:'float 4s ease-in-out infinite',
            filter:'drop-shadow(0 0 28px rgba(139,92,246,.4))'}}>
            <Hat/>
          </div>
          <h1 style={{fontSize:26,fontWeight:300,letterSpacing:'-.02em',marginBottom:8}}>
            You&apos;re <span style={{fontWeight:700,color:'var(--ac)'}}>privately</span> browsing
          </h1>
          <p style={{color:'var(--mu)',fontSize:14,lineHeight:1.6}}>
            Type any URL or search term below
          </p>
        </div>

        {/* URL / search bar */}
        <div style={{display:'flex',gap:8,marginBottom:36,
          background:'var(--s1)',border:'1px solid var(--br)',borderRadius:28,
          padding:'6px 8px 6px 18px',boxShadow:'0 4px 24px rgba(0,0,0,.3)'}}>
          <input ref={inputRef} type="text" value={q} onChange={e => setQ(e.target.value)} onKeyDown={onKey}
            placeholder="Search or enter a URL…"
            style={{flex:1,background:'transparent',border:'none',outline:'none',color:'var(--tx)',
              fontSize:15,fontFamily:'var(--sans)',minWidth:0}}/>
          <button onClick={() => go(q)}
            style={{padding:'8px 20px',background:'var(--ac)',border:'none',borderRadius:22,
              color:'#fff',fontWeight:600,fontSize:14,cursor:'pointer',flexShrink:0,
              boxShadow:'0 2px 12px rgba(139,92,246,.4)'}}>
            Go
          </button>
        </div>

        {/* Quick links */}
        <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fill,minmax(140px,1fr))',gap:10,marginBottom:36}}>
          {QUICK.map(([label, url]) => (
            <button key={label} className="ql" onClick={() => go(url)}>{label}</button>
          ))}
        </div>

        {/* Privacy cards */}
        <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fill,minmax(260px,1fr))',gap:10}}>
          {BULLETS.map((b,i) => (
            <div key={i} className="pc">
              <span style={{width:7,height:7,borderRadius:'50%',background:'var(--ac)',flexShrink:0,
                marginTop:4,boxShadow:'0 0 8px var(--ac)',display:'inline-block'}}/>
              <span>{b}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ── Root ───────────────────────────────────────────────────────────────────────
export default function Browse() {
  const [ok, setOk] = useState(false);

  useEffect(() => {
    try { if (sessionStorage.getItem(SK) === '1') setOk(true); } catch {}
  }, []);

  if (!ok) return <PinGate onUnlock={() => setOk(true)} />;
  return <NewTab />;
}
