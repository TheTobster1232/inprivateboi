export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

const STRIP_HEADERS = new Set([
  'content-security-policy','content-security-policy-report-only',
  'x-frame-options','x-xss-protection','strict-transport-security',
  'set-cookie','report-to','nel','expect-ct','permissions-policy',
  'cross-origin-opener-policy','cross-origin-embedder-policy',
  'cross-origin-resource-policy','content-encoding','transfer-encoding',
  'content-length',
]);

// ── Decompress ─────────────────────────────────────────────────────────────────
async function decompress(response) {
  const enc = (response.headers.get('content-encoding') || '').toLowerCase();
  const buf = Buffer.from(await response.arrayBuffer());
  if (!enc || enc === 'identity') return buf;
  const zlib = await import('node:zlib');
  const { promisify } = await import('node:util');
  if (enc === 'gzip' || enc === 'x-gzip') return promisify(zlib.gunzip)(buf);
  if (enc === 'deflate') {
    return promisify(zlib.inflate)(buf).catch(() => promisify(zlib.inflateRaw)(buf));
  }
  if (enc === 'br') return promisify(zlib.brotliDecompress)(buf);
  return buf;
}

// ── URL rewriting ──────────────────────────────────────────────────────────────
function isAlreadyProxied(s, origin) {
  try { const u = new URL(s, origin); return u.pathname === '/api/proxy' && u.searchParams.has('url'); }
  catch { return false; }
}

function toProxy(raw, base, pb, origin) {
  if (!raw) return raw;
  const s = raw.trim();
  if (/^(data:|blob:|javascript:|#|mailto:|tel:|about:|{)/i.test(s)) return s;
  if (isAlreadyProxied(s, origin)) return s;
  try {
    const abs = new URL(s.startsWith('//') ? 'https:' + s : s, base).href;
    if (/^https?:\/\//i.test(abs)) return pb + encodeURIComponent(abs);
  } catch {}
  return raw;
}

function rewriteAttr(html, attr, base, pb, origin) {
  return html.replace(
    new RegExp(`(\\b${attr}\\s*=\\s*)("([^"]*?)"|'([^']*?)')`, 'gi'),
    (_, pre, _q, dq, sq) => {
      const val = dq !== undefined ? dq : sq;
      const q = dq !== undefined ? '"' : "'";
      return `${pre}${q}${toProxy(val, base, pb, origin)}${q}`;
    }
  );
}

function rewriteCss(css, base, pb, origin) {
  css = css.replace(/url\(\s*(['"]?)([^)'"]+)\1\s*\)/gi,
    (_, q, u) => `url(${q}${toProxy(u.trim(), base, pb, origin)}${q})`);
  css = css.replace(/@import\s+(?:url\(\s*['"]?([^)'"\s]+)['"]?\s*\)|['"]([^'"]+)['"])/gi,
    (_, u1, u2) => `@import url("${toProxy(u1 || u2, base, pb, origin)}")`);
  return css;
}

function rewriteHtml(html, finalUrl, pb, origin) {
  // Kill base tags — we rewrite everything ourselves
  html = html.replace(/<base[^>]*>/gi, '');

  // Rewrite resource attrs
  for (const a of ['src','href','action','poster','data-src','data-href','data-url','data-background']) {
    html = rewriteAttr(html, a, finalUrl, pb, origin);
  }

  // srcset
  html = html.replace(/(\bsrcset\s*=\s*)("([^"]*?)"|'([^']*?)')/gi, (_, p, _q, dq, sq) => {
    const val = dq !== undefined ? dq : sq, q = dq !== undefined ? '"' : "'";
    return `${p}${q}${val.replace(/([^\s,]+)(\s+[\d.]+[wx])?/g, (m, u, d) => toProxy(u, finalUrl, pb, origin) + (d||''))}${q}`;
  });

  // Inline <style>
  html = html.replace(/(<style[^>]*>)([\s\S]*?)(<\/style>)/gi,
    (_, o, css, c) => o + rewriteCss(css, finalUrl, pb, origin) + c);

  // style="" attributes
  html = html.replace(/(\bstyle\s*=\s*)("([^"]*?)"|'([^']*?)')/gi, (_, p, _q, dq, sq) => {
    const val = dq !== undefined ? dq : sq, q = dq !== undefined ? '"' : "'";
    return `${p}${q}${rewriteCss(val, finalUrl, pb, origin)}${q}`;
  });

  // Inject toolbar + intercept script before </head>
  const toolbar = buildToolbar(finalUrl, pb, origin);
  if (/<\/head>/i.test(html)) return html.replace(/<\/head>/i, toolbar + '\n</head>');
  if (/<body[\s>]/i.test(html)) return html.replace(/<body[\s>]/i, m => toolbar + '\n' + m);
  return toolbar + '\n' + html;
}

function buildToolbar(finalUrl, pb, origin) {
  const safeUrl = JSON.stringify(finalUrl);
  const safePb  = JSON.stringify(pb);

  return `
<style id="__pb_style__">
  #__pb_bar__ *{box-sizing:border-box!important;font-family:system-ui,-apple-system,sans-serif!important;}
  #__pb_bar__{position:fixed!important;top:0!important;left:0!important;right:0!important;z-index:2147483647!important;
    height:46px!important;background:#1c1d1f!important;border-bottom:1px solid #2e3032!important;
    display:flex!important;align-items:center!important;padding:0 10px!important;gap:6px!important;
    box-shadow:0 2px 16px rgba(0,0,0,.5)!important;}
  #__pb_bar__ button{display:flex!important;align-items:center!important;justify-content:center!important;
    width:30px!important;height:30px!important;border:none!important;background:transparent!important;
    color:#7a7d82!important;border-radius:6px!important;cursor:pointer!important;font-size:16px!important;flex-shrink:0!important;}
  #__pb_bar__ button:hover{background:#2e3032!important;color:#e8e9ea!important;}
  #__pb_url__{flex:1!important;height:30px!important;background:#242628!important;border:1px solid #2e3032!important;
    border-radius:15px!important;color:#e8e9ea!important;font-size:12px!important;padding:0 12px!important;
    outline:none!important;font-family:'Courier New',monospace!important;min-width:0!important;}
  #__pb_url__:focus{border-color:#8b5cf6!important;box-shadow:0 0 0 2px rgba(139,92,246,.25)!important;}
  #__pb_badge__{font-size:10px!important;font-weight:600!important;color:#8b5cf6!important;padding:3px 10px!important;
    background:rgba(139,92,246,.15)!important;border:1px solid #5b3fa6!important;border-radius:20px!important;
    white-space:nowrap!important;flex-shrink:0!important;letter-spacing:.05em!important;}
  html{margin-top:46px!important;}
  body{margin-top:0!important;}
</style>
<div id="__pb_bar__">
  <button id="__pb_back__" title="Back">&#8592;</button>
  <button id="__pb_fwd__"  title="Forward">&#8594;</button>
  <button id="__pb_reload__" title="Reload">&#8635;</button>
  <button id="__pb_home__" title="Home">&#8962;</button>
  <input id="__pb_url__" type="text" spellcheck="false" autocomplete="off" />
  <span id="__pb_badge__">&#128274; PRIVATE</span>
</div>
<script id="__pb_script__">
(function(){
  var PB=${safePb}, BASE=${safeUrl}, ORIGIN=${JSON.stringify(origin)};
  var bar=document.getElementById('__pb_bar__');

  function px(u){
    if(!u) return u; var s=String(u).trim();
    if(/^(data:|blob:|javascript:|#|mailto:|tel:|about:)/i.test(s)) return s;
    try{ var c=new URL(s,ORIGIN); if(c.pathname==='/api/proxy'&&c.searchParams.has('url')) return s; }catch(e){}
    try{
      var abs=new URL(s.startsWith('//')?'https:'+s:s, BASE).href;
      if(/^https?:\\/\\//.test(abs)) return PB+encodeURIComponent(abs);
    }catch(e){}
    return u;
  }

  // URL bar
  var inp=document.getElementById('__pb_url__');
  inp.value=BASE;
  inp.addEventListener('keydown',function(e){
    if(e.key!=='Enter') return;
    var v=this.value.trim(); if(!v) return;
    if(v.includes(' ')||!v.includes('.')){
      v='https://lite.duckduckgo.com/lite/?q='+encodeURIComponent(v);
    } else if(!/^https?:\\/\\//i.test(v)) v='https://'+v;
    window.location.href=PB+encodeURIComponent(v);
  });

  // Nav buttons
  document.getElementById('__pb_back__').onclick=function(){history.back();};
  document.getElementById('__pb_fwd__').onclick=function(){history.forward();};
  document.getElementById('__pb_reload__').onclick=function(){location.reload();};
  document.getElementById('__pb_home__').onclick=function(){location.href='/browse';};

  // Intercept link clicks
  document.addEventListener('click',function(e){
    if(bar.contains(e.target)) return;
    var a=e.target.closest?e.target.closest('a[href]'):null;
    if(!a) return;
    var h=a.getAttribute('href');
    if(!h||/^(javascript:|mailto:|tel:|#)/i.test(h)) return;
    var p=px(a.href||h);
    if(p&&p!==location.href){e.preventDefault();e.stopPropagation();location.href=p;}
  },true);

  // Intercept form submits
  document.addEventListener('submit',function(e){
    if(bar.contains(e.target)) return;
    var f=e.target;
    var method=(f.getAttribute('method')||'get').toLowerCase();
    e.preventDefault();
    if(method==='get'){
      // Build target URL from action + form data, then proxy it
      var rawAction=f.getAttribute('action')||BASE;
      // If already proxied, extract inner URL
      var targetBase=rawAction;
      try{
        var pa=new URL(rawAction,ORIGIN);
        if(pa.pathname==='/api/proxy'&&pa.searchParams.has('url')){
          targetBase=decodeURIComponent(pa.searchParams.get('url'));
        }
      }catch(e2){}
      var tb=new URL(targetBase.startsWith('//')?'https:'+targetBase:targetBase, BASE);
      var fd=new URLSearchParams(new FormData(f));
      fd.forEach(function(v,k){ tb.searchParams.set(k,v); });
      location.href=PB+encodeURIComponent(tb.href);
    } else {
      // POST: rewrite action to our proxy endpoint and submit
      var rawAction2=f.getAttribute('action')||BASE;
      f.setAttribute('action', px(rawAction2));
      f.submit();
    }
  },true);

  // MutationObserver for dynamic images
  if(window.MutationObserver){
    new MutationObserver(function(ms){
      ms.forEach(function(m){
        m.addedNodes.forEach(function(n){
          if(n.nodeType!==1) return;
          var els=[n].concat(Array.from(n.querySelectorAll?n.querySelectorAll('img,source,script[src],link[rel*=stylesheet]'):[]));
          els.forEach(function(el){
            if(!el.getAttribute||el.getAttribute('data-pb')) return;
            el.setAttribute('data-pb','1');
            if(el.src){var r=px(el.src);if(r!==el.src)el.src=r;}
            if(el.href&&el.rel&&el.rel.includes('stylesheet')){var r=px(el.href);if(r!==el.href)el.href=r;}
          });
        });
      });
    }).observe(document.documentElement,{childList:true,subtree:true});
  }
})();
<\/script>`;
}

// ── Headers ────────────────────────────────────────────────────────────────────
const FETCH_HEADERS = {
  'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
  'Accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
  'Accept-Language':'en-US,en;q=0.9',
  'Accept-Encoding':'gzip, deflate, br',
  'Cache-Control':'no-cache',
  'DNT':'1',
  'Upgrade-Insecure-Requests':'1',
};

function outHeaders(upstream) {
  const h = new Headers();
  for (const [k,v] of upstream.headers.entries()) {
    if (!STRIP_HEADERS.has(k.toLowerCase())) h.set(k, v);
  }
  h.set('Access-Control-Allow-Origin','*');
  h.delete('content-length');
  return h;
}

function blocked(host) {
  return ['localhost','127.0.0.1','0.0.0.0','::1'].includes(host) || host.endsWith('.local');
}

// ── GET ────────────────────────────────────────────────────────────────────────
export async function GET(request) {
  const req = new URL(request.url);
  const origin = req.origin;
  let url = req.searchParams.get('url') || '';
  if (!url) return Response.json({error:'Missing ?url='},{status:400});
  if (!/^https?:\/\//i.test(url)) url = 'https://' + url;

  let parsed;
  try { parsed = new URL(url); } catch { return Response.json({error:'Bad URL'},{status:400}); }
  if (blocked(parsed.hostname)) return Response.json({error:'Blocked'},{status:403});

  const pb = origin + '/api/proxy?url=';
  let upstream;
  try {
    upstream = await fetch(url, { headers: FETCH_HEADERS, redirect:'follow', signal: AbortSignal.timeout(15000) });
  } catch(e) {
    return new Response(errPage(url, e.message), {status:502, headers:{'Content-Type':'text/html'}});
  }

  const final = upstream.url;
  const ct = upstream.headers.get('content-type') || '';
  const isHtml = ct.includes('text/html');
  const isCss  = ct.includes('text/css');
  const h = outHeaders(upstream);

  const buf = await decompress(upstream);

  if (isHtml) {
    const body = rewriteHtml(buf.toString('utf-8'), final, pb, origin);
    h.set('Content-Type','text/html; charset=utf-8');
    return new Response(body, {status:upstream.status, headers:h});
  }
  if (isCss) {
    const body = rewriteCss(buf.toString('utf-8'), final, pb, origin);
    h.set('Content-Type', ct);
    return new Response(body, {status:upstream.status, headers:h});
  }
  h.set('Content-Type', ct);
  return new Response(buf, {status:upstream.status, headers:h});
}

// ── POST ───────────────────────────────────────────────────────────────────────
export async function POST(request) {
  const req = new URL(request.url);
  const origin = req.origin;
  let url = req.searchParams.get('url') || '';
  if (!url) return Response.json({error:'Missing ?url='},{status:400});
  if (!/^https?:\/\//i.test(url)) url = 'https://' + url;

  let parsed;
  try { parsed = new URL(url); } catch { return Response.json({error:'Bad URL'},{status:400}); }
  if (blocked(parsed.hostname)) return Response.json({error:'Blocked'},{status:403});

  const pb = origin + '/api/proxy?url=';
  const ct = request.headers.get('content-type') || '';
  const body = ct.includes('application/x-www-form-urlencoded') ? await request.text() : await request.arrayBuffer();

  let upstream;
  try {
    upstream = await fetch(url, {
      method:'POST',
      headers:{...FETCH_HEADERS,'Content-Type':ct,'Origin':parsed.origin,'Referer':parsed.origin+'/'},
      body, redirect:'follow', signal:AbortSignal.timeout(15000),
    });
  } catch(e) {
    return new Response(errPage(url, e.message), {status:502, headers:{'Content-Type':'text/html'}});
  }

  const final = upstream.url;
  const rct = upstream.headers.get('content-type') || '';
  const h = outHeaders(upstream);
  const buf = await decompress(upstream);

  if (rct.includes('text/html')) {
    const out = rewriteHtml(buf.toString('utf-8'), final, pb, origin);
    h.set('Content-Type','text/html; charset=utf-8');
    return new Response(out, {status:upstream.status, headers:h});
  }
  h.set('Content-Type', rct);
  return new Response(buf, {status:upstream.status, headers:h});
}

// ── Error page ─────────────────────────────────────────────────────────────────
function errPage(url, reason) {
  return `<!DOCTYPE html><html><head><meta charset="utf-8"><title>Error</title>
<style>body{margin:0;background:#111213;color:#e8e9ea;font-family:system-ui,sans-serif;display:flex;align-items:center;justify-content:center;min-height:100vh;}
.b{text-align:center;max-width:480px;padding:40px;}h2{color:#ef4444;margin:0 0 12px;}
p{color:#7a7d82;font-size:14px;line-height:1.6;margin:0 0 16px;}
code{display:block;padding:10px 16px;background:#1c1d1f;border:1px solid #2e3032;border-radius:8px;font-size:12px;word-break:break-all;color:#8b5cf6;margin-bottom:8px;}
small{color:#4a4d54;font-size:11px;}
a{color:#8b5cf6;text-decoration:none;}a:hover{text-decoration:underline;}</style></head>
<body><div class="b"><h2>&#9888; Could not load page</h2>
<p>The site may block server-side requests, require a login, or be temporarily down.</p>
<code>${url}</code><small>${reason}</small><br><br>
<a href="/browse">&#8962; Back to home</a></div></body></html>`;
}
