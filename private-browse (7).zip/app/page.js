'use client';
import { useState, useEffect } from 'react';

function Clock() {
  const [time, setTime] = useState('');
  const [date, setDate] = useState('');
  useEffect(() => {
    const tick = () => {
      const now = new Date();
      setTime(now.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit', second: '2-digit' }));
      setDate(now.toLocaleDateString('en-GB', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' }));
    };
    tick();
    const id = setInterval(tick, 1000);
    return () => clearInterval(id);
  }, []);
  return (
    <div style={{ textAlign: 'center', marginBottom: 40 }}>
      <div style={{ fontSize: 56, fontWeight: 200, letterSpacing: '-0.03em', color: '#1a1a2e', fontFamily: 'Georgia, serif' }}>{time}</div>
      <div style={{ fontSize: 15, color: '#888', marginTop: 4 }}>{date}</div>
    </div>
  );
}

const LINKS = [
  { label: 'BBC News', url: 'https://bbc.co.uk/news' },
  { label: 'Wikipedia', url: 'https://en.wikipedia.org' },
  { label: 'Khan Academy', url: 'https://khanacademy.org' },
  { label: 'Wolfram Alpha', url: 'https://wolframalpha.com' },
  { label: 'Desmos', url: 'https://desmos.com' },
  { label: 'GitHub', url: 'https://github.com' },
];

export default function CoverPage() {
  const [notes, setNotes] = useState('');
  useEffect(() => {
    try { setNotes(localStorage.getItem('cover_notes') || ''); } catch {}
  }, []);
  const saveNotes = (v) => {
    setNotes(v);
    try { localStorage.setItem('cover_notes', v); } catch {}
  };

  return (
    <>
      <style>{`
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
        body { background: #f5f5f0; font-family: system-ui, -apple-system, sans-serif; color: #222; min-height: 100vh; }
        .page { max-width: 820px; margin: 0 auto; padding: 60px 24px 80px; }
        h2 { font-size: 11px; font-weight: 500; letter-spacing: 0.12em; text-transform: uppercase; color: #aaa; margin-bottom: 14px; }
        .card { background: #fff; border-radius: 12px; border: 1px solid #e8e8e8; padding: 20px; box-shadow: 0 1px 4px rgba(0,0,0,0.04); }
        .links-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(150px, 1fr)); gap: 10px; }
        .link-btn { display: block; padding: 12px 14px; background: #fafafa; border: 1px solid #e8e8e8; border-radius: 8px;
          text-decoration: none; color: #333; font-size: 13px; font-weight: 500; transition: all 0.15s; text-align: center; }
        .link-btn:hover { background: #f0f0f0; border-color: #ccc; }
        textarea { width: 100%; height: 160px; border: none; outline: none; resize: none; font-size: 14px; color: #333;
          font-family: inherit; line-height: 1.6; background: transparent; }
        textarea::placeholder { color: #ccc; }
        .footer { text-align: center; font-size: 12px; color: #ccc; margin-top: 60px; }
      `}</style>
      <div className="page">
        <Clock />
        <div style={{ marginBottom: 28 }}>
          <h2>Quick Links</h2>
          <div className="card">
            <div className="links-grid">
              {LINKS.map(l => (
                <a key={l.label} href={l.url} target="_blank" rel="noreferrer" className="link-btn">{l.label}</a>
              ))}
            </div>
          </div>
        </div>
        <div style={{ marginBottom: 28 }}>
          <h2>Notes</h2>
          <div className="card">
            <textarea value={notes} onChange={e => saveNotes(e.target.value)} placeholder="Jot something down — saves automatically..." />
          </div>
        </div>
        <p className="footer">Personal start page &mdash; v1.0</p>
      </div>
    </>
  );
}
