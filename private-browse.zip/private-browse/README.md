# 🕵️ Private Browse — Server-Side Privacy Proxy

A deployable, functional alternative to Incognito/InPrivate mode.  
Every page request is made **from the server**, not from your browser — hiding your IP, browser fingerprint, and identity from sites you visit.

---

## How It Works

| Feature | Incognito/InPrivate | Private Browse |
|---------|---------------------|----------------|
| Hides browsing from local device | ✅ | ✅ (nothing is stored) |
| Hides your IP from target sites | ❌ | ✅ (server makes the request) |
| Blocks browser fingerprinting | ❌ | ✅ |
| Strips tracking headers | ❌ | ✅ |
| Blocks cookies from being set | Partially | ✅ (completely) |
| Works in any browser tab | ❌ | ✅ |

---

## Deploy to Vercel (recommended — 5 minutes)

### Step 1: Push to GitHub

```bash
cd private-browse
git init
git add .
git commit -m "Initial commit"
# Create a new repo on github.com, then:
git remote add origin https://github.com/YOUR_USERNAME/private-browse.git
git branch -M main
git push -u origin main
```

### Step 2: Deploy on Vercel

1. Go to [vercel.com/new](https://vercel.com/new)
2. Import your GitHub repo (`private-browse`)
3. Framework: **Next.js** (auto-detected)
4. Click **Deploy**

That's it. Vercel will give you a URL like `private-browse.vercel.app`.

---

## Run Locally

```bash
npm install
npm run dev
# Open http://localhost:3000
```

---

## Deploy with Docker (optional)

If you prefer self-hosting on a VPS, EC2, or any Docker host:

### Dockerfile

Create this file in the project root:

```dockerfile
FROM node:20-alpine AS builder
WORKDIR /app
COPY package.json ./
RUN npm install
COPY . .
RUN npm run build

FROM node:20-alpine AS runner
WORKDIR /app
ENV NODE_ENV=production
COPY --from=builder /app/.next ./.next
COPY --from=builder /app/node_modules ./node_modules
COPY --from=builder /app/package.json ./package.json
COPY --from=builder /app/next.config.mjs ./next.config.mjs
EXPOSE 3000
CMD ["npm", "start"]
```

```bash
# Build
docker build -t private-browse .

# Run
docker run -p 3000:3000 private-browse
```

### With docker-compose

```yaml
version: '3.8'
services:
  app:
    build: .
    ports:
      - "3000:3000"
    restart: unless-stopped
    environment:
      - NODE_ENV=production
```

```bash
docker-compose up -d
```

---

## Limitations

Some sites actively block proxying:
- Sites requiring JavaScript login flows (Google, Facebook) — their JS runs on the server, not in your browser
- Sites using WebSockets for real-time content
- Heavily JavaScript-rendered SPAs may not fully work  
- HTTPS-only APIs that reject non-browser clients

Works great for: news sites, Wikipedia, documentation, forums, blogs, Hacker News, etc.

---

## Architecture

```
User Browser
    │
    ▼
Next.js App (Vercel Edge)
    ├── /          → Browser UI (URL bar + iframe)
    └── /api/proxy → Fetches target URL server-side
                     - Strips CSP / X-Frame-Options
                     - Strips Set-Cookie
                     - Injects link-intercept script
                     - Returns clean HTML
```

---

## License

MIT — do whatever you want with it.
