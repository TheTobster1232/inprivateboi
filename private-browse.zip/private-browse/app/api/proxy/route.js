// app/api/proxy/route.js
// Server-side privacy proxy — all requests made from the server, not the client.
// Strips CSP, tracking headers, cookies. Nothing is logged or persisted.

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

// Headers we strip from upstream responses to allow iframe embedding & remove tracking
const STRIP_RESPONSE_HEADERS = new Set([
  'content-security-policy',
  'content-security-policy-report-only',
  'x-frame-options',
  'x-xss-protection',
  'strict-transport-security',
  'set-cookie',                // Don't let target sites set cookies in our domain
  'report-to',
  'nel',
  'expect-ct',
  'permissions-policy',
  'cross-origin-opener-policy',
  'cross-origin-embedder-policy',
  'cross-origin-resource-policy',
]);

function resolveUrl(href, base) {
  try {
    return new URL(href, base).href;
  } catch {
    return null;
  }
}

function rewriteUrlForProxy(href, base, proxyBase) {
  const abs = resolveUrl(href, base);
  if (!abs) return href;
  if (abs.startsWith('http://') || abs.startsWith('https://')) {
    return proxyBase + encodeURIComponent(abs);
  }
  return href;
}

// Rewrite src/href attributes in HTML to route through proxy
function rewriteHtml(html, finalUrl, proxyBase) {
  const parsedBase = new URL(finalUrl);
  const origin = parsedBase.origin;

  // Remove existing base tags
  html = html.replace(/<base[^>]*>/gi, '');

  // The client-side intercept script injected into every proxied page
  const interceptScript = `
<script data-proxy="intercept">
(function() {
  'use strict';
  var PROXY = '${proxyBase}';
  var BASE  = '${finalUrl}';

  function toProxyUrl(url) {
    try {
      var abs = new URL(url, BASE).href;
      if (/^https?:\\/\\//.test(abs)) return PROXY + encodeURIComponent(abs);
    } catch(e) {}
    return null;
  }

  // Intercept <a> clicks
  document.addEventListener('click', function(e) {
    var a = e.target.closest('a[href]');
    if (!a) return;
    var href = a.getAttribute('href');
    if (!href || href.startsWith('javascript:') || href.startsWith('mailto:') || href.startsWith('#')) return;
    var proxied = toProxyUrl(a.href || href);
    if (proxied) { e.preventDefault(); e.stopPropagation(); window.location.href = proxied; }
  }, true);

  // Intercept GET form submits
  document.addEventListener('submit', function(e) {
    var form = e.target;
    var method = (form.getAttribute('method') || 'get').toLowerCase();
    if (method !== 'get') return; // POST forms are complex; skip for safety
    e.preventDefault();
    var action = form.action || BASE;
    var params  = new URLSearchParams(new FormData(form)).toString();
    var url = action + (params ? (action.includes('?') ? '&' : '?') + params : '');
    var proxied = toProxyUrl(url);
    if (proxied) window.location.href = proxied;
  }, true);

  // Update parent frame URL bar if inside iframe
  function notifyParent() {
    try {
      if (window.parent && window.parent !== window) {
        window.parent.postMessage({ type: 'PROXY_NAV', url: window.location.href }, '*');
      }
    } catch(e) {}
  }
  notifyParent();
})();
</script>`;

  // Inject base href for relative resource resolution + our intercept script
  const injection = `<base href="${origin}/">\n${interceptScript}`;

  if (/<\/head>/i.test(html)) {
    html = html.replace(/<\/head>/i, injection + '\n</head>');
  } else if (/<body/i.test(html)) {
    html = html.replace(/<body/i, injection + '\n<body');
  } else {
    html = injection + '\n' + html;
  }

  return html;
}

export async function GET(request) {
  const { searchParams } = new URL(request.url);
  let targetUrl = searchParams.get('url') || '';

  if (!targetUrl) {
    return Response.json({ error: 'Missing ?url= parameter' }, { status: 400 });
  }

  // Auto-prepend https:// if missing
  if (!/^https?:\/\//i.test(targetUrl)) {
    targetUrl = 'https://' + targetUrl;
  }

  let parsedTarget;
  try {
    parsedTarget = new URL(targetUrl);
  } catch {
    return Response.json({ error: 'Invalid URL' }, { status: 400 });
  }

  // Block attempts to proxy our own server (SSRF guard)
  const blocked = ['localhost', '127.0.0.1', '0.0.0.0', '::1'];
  if (blocked.some(h => parsedTarget.hostname === h) || parsedTarget.hostname.endsWith('.local')) {
    return Response.json({ error: 'Blocked: private/loopback addresses' }, { status: 403 });
  }

  const proxyBase = new URL(request.url).origin + '/api/proxy?url=';

  let upstream;
  try {
    upstream = await fetch(targetUrl, {
      method: 'GET',
      headers: {
        'User-Agent':
          'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
        Accept:
          'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5',
        'Accept-Encoding': 'identity',   // Avoid compressed responses we can't easily rewrite
        DNT: '1',
        'Sec-GPC': '1',
      },
      redirect: 'follow',
      signal: AbortSignal.timeout(12000),
    });
  } catch (err) {
    return Response.json(
      { error: `Could not reach ${targetUrl}: ${err.message}` },
      { status: 502 }
    );
  }

  const finalUrl  = upstream.url;           // After any redirects
  const rawCT     = upstream.headers.get('content-type') || 'application/octet-stream';
  const isHtml    = rawCT.includes('text/html');
  const isText    = rawCT.includes('text/') || rawCT.includes('javascript') || rawCT.includes('json');

  // Build clean response headers
  const responseHeaders = new Headers();
  for (const [k, v] of upstream.headers.entries()) {
    if (!STRIP_RESPONSE_HEADERS.has(k.toLowerCase())) {
      responseHeaders.set(k, v);
    }
  }
  // Allow iframe embedding from same origin
  responseHeaders.set('X-Frame-Options', 'SAMEORIGIN');
  responseHeaders.set('X-Proxied-By', 'private-browse');
  responseHeaders.set('X-Final-Url', finalUrl);

  if (isHtml) {
    const raw = await upstream.text();
    const rewritten = rewriteHtml(raw, finalUrl, proxyBase);
    responseHeaders.set('Content-Type', 'text/html; charset=utf-8');
    return new Response(rewritten, {
      status: upstream.status,
      headers: responseHeaders,
    });
  }

  // For CSS / JS / images / fonts — stream through unchanged
  const body = await upstream.arrayBuffer();
  responseHeaders.set('Content-Type', rawCT);
  return new Response(body, {
    status: upstream.status,
    headers: responseHeaders,
  });
}
