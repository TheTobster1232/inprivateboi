'use client';

import { useState, useRef, useEffect, useCallback } from 'react';

// ─── Incognito hat SVG (same concept as Chrome's, drawn from scratch) ──────────
function IncognitoIcon({ size = 80 }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 80 80"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      {/* Hat brim */}
      <ellipse cx="40" cy="34" rx="32" ry="8" fill="#3d3f44" />
      {/* Hat crown */}
      <rect x="22" y="10" width="36" height="26" rx="4" fill="#3d3f44" />
      {/* Hat band */}
      <rect x="22" y="28" width="36" height="6" fill="#2a2b2f" />
      {/* Face */}
      <ellipse cx="40" cy="54" rx="18" ry="16" fill="#4a4d54" />
      {/* Glasses frame left */}
      <rect x="16" y="48" width="19" height="13" rx="6" fill="#1c1d1f" stroke="#8b5cf6" strokeWidth="2" />
      {/* Glasses frame right */}
      <rect x="45" y="48" width="19" height="13" rx="6" fill="#1c1d1f" stroke="#8b5cf6" strokeWidth="2" />
      {/* Bridge */}
      <line x1="35" y1="54" x2="45" y2="54" stroke="#8b5cf6" strokeWidth="2" />
      {/* Eyes */}
      <circle cx="25.5" cy="54.5" r="3" fill="#8b5cf6" opacity="0.7" />
      <circle cx="54.5" cy="54.5" r="3" fill="#8b5cf6" opacity="0.7" />
    </svg>
  );
}

function LockIcon() {
  return (
    <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
      <rect x="3" y="6" width="8" height="6" rx="1.5" fill="#8b5cf6" />
      <path d="M4.5 6V4.5a2.5 2.5 0 0 1 5 0V6" stroke="#8b5cf6" strokeWidth="1.4" strokeLinecap="round" />
    </svg>
  );
}

function ShieldIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
      <path d="M8 1.5L2 4v4c0 3.3 2.6 5.7 6 6.5 3.4-.8 6-3.2 6-6.5V4L8 1.5z" fill="#8b5cf6" opacity="0.2" stroke="#8b5cf6" strokeWidth="1.2" strokeLinejoin="round" />
      <path d="M5.5 8l1.8 1.8L10.5 6" stroke="#8b5cf6" strokeWidth="1.3" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

function RefreshIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
      <path d="M13.5 8A5.5 5.5 0 1 1 8 2.5c1.5 0 2.9.6 3.9 1.6L13.5 5.6" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
      <polyline points="10,3 13.5,3 13.5,6.5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

function BackIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
      <path d="M10 12L6 8l4-4" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

function ForwardIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
      <path d="M6 12l4-4-4-4" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

function HomeIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
      <path d="M2 7.5L8 2l6 5.5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
      <rect x="5" y="8.5" width="6" height="5" rx="1" stroke="currentColor" strokeWidth="1.5" />
    </svg>
  );
}

const PRIVACY_BULLETS = [
  'Pages you visit are fetched server-side — your browser never connects to the target site.',
  'No browsing history, cookies, or session data is saved anywhere.',
  "Tracking scripts and fingerprinting can\u2019t profile you \u2014 they see the server, not you.",
  'Each session starts clean. Close the tab and everything is gone.',
];

export default function Page() {
  const [inputUrl, setInputUrl]     = useState('');
  const [iframeSrc, setIframeSrc]   = useState('');
  const [displayUrl, setDisplayUrl] = useState('');
  const [loading, setLoading]       = useState(false);
  const [error, setError]           = useState('');

  const iframeRef = useRef(null);
  const inputRef  = useRef(null);

  const navigate = useCallback((raw) => {
    let url = raw.trim();
    if (!url) return;

    // If it looks like a search term (no dots / spaces), use DuckDuckGo
    if (!url.includes('.') || url.includes(' ')) {
      url = 'https://duckduckgo.com/?q=' + encodeURIComponent(url);
    } else if (!/^https?:\/\//i.test(url)) {
      url = 'https://' + url;
    }

    setError('');
    setLoading(true);
    setDisplayUrl(url);
    setIframeSrc('/api/proxy?url=' + encodeURIComponent(url));
    setInputUrl(url);
  }, []);

  const handleSubmit = (e) => {
    e.preventDefault();
    navigate(inputUrl);
  };

  const handleRefresh = () => {
    if (iframeSrc) {
      const current = iframeSrc;
      setIframeSrc('');
      setTimeout(() => setIframeSrc(current), 50);
      setLoading(true);
    }
  };

  const handleHome = () => {
    setIframeSrc('');
    setDisplayUrl('');
    setInputUrl('');
    setError('');
    setLoading(false);
  };

  // Listen for navigation events from inside the iframe
  useEffect(() => {
    const onMessage = (e) => {
      if (e.data?.type === 'PROXY_NAV') {
        const proxiedUrl = e.data.url;
        // Extract the original ?url= param
        try {
          const u = new URL(proxiedUrl, window.location.origin);
          const original = u.searchParams.get('url');
          if (original) {
            setDisplayUrl(decodeURIComponent(original));
            setInputUrl(decodeURIComponent(original));
          }
        } catch {}
      }
    };
    window.addEventListener('message', onMessage);
    return () => window.removeEventListener('message', onMessage);
  }, []);

  const isPrivate = !!iframeSrc;

  return (
    <>
      <style>{`
        .browser-shell {
          display: flex;
          flex-direction: column;
          height: 100dvh;
          background: var(--bg);
          overflow: hidden;
        }

        /* ── Toolbar ── */
        .toolbar {
          display: flex;
          align-items: center;
          gap: 6px;
          padding: 8px 12px;
          background: var(--surface);
          border-bottom: 1px solid var(--border);
          flex-shrink: 0;
          user-select: none;
        }

        .nav-btn {
          display: flex;
          align-items: center;
          justify-content: center;
          width: 32px;
          height: 32px;
          border: none;
          background: transparent;
          color: var(--muted);
          border-radius: 6px;
          cursor: pointer;
          transition: background 0.15s, color 0.15s;
          flex-shrink: 0;
        }
        .nav-btn:hover:not(:disabled) {
          background: var(--surface2);
          color: var(--text);
        }
        .nav-btn:disabled {
          opacity: 0.3;
          cursor: default;
        }

        .url-form {
          flex: 1;
          display: flex;
          align-items: center;
          gap: 8px;
          background: var(--surface2);
          border: 1px solid var(--border);
          border-radius: 22px;
          padding: 0 14px;
          height: 36px;
          transition: border-color 0.15s, box-shadow 0.15s;
        }
        .url-form:focus-within {
          border-color: var(--accent);
          box-shadow: 0 0 0 3px var(--accent-glow);
        }

        .url-input {
          flex: 1;
          background: transparent;
          border: none;
          outline: none;
          color: var(--text);
          font-family: var(--mono);
          font-size: 13px;
          min-width: 0;
        }
        .url-input::placeholder { color: var(--muted); }

        .private-badge {
          display: flex;
          align-items: center;
          gap: 5px;
          font-size: 11px;
          font-weight: 500;
          color: var(--accent);
          white-space: nowrap;
          letter-spacing: 0.03em;
          padding: 3px 10px;
          background: var(--accent-glow);
          border: 1px solid var(--accent-dim);
          border-radius: 20px;
          flex-shrink: 0;
        }

        /* ── Progress bar ── */
        .progress-bar {
          height: 2px;
          background: transparent;
          flex-shrink: 0;
          position: relative;
          overflow: hidden;
        }
        .progress-bar.loading::after {
          content: '';
          position: absolute;
          left: -60%;
          top: 0;
          width: 60%;
          height: 100%;
          background: linear-gradient(90deg, transparent, var(--accent), transparent);
          animation: slide 1s linear infinite;
        }
        @keyframes slide {
          to { left: 160%; }
        }

        /* ── Iframe viewport ── */
        .viewport {
          flex: 1;
          overflow: hidden;
          position: relative;
        }
        .proxy-iframe {
          width: 100%;
          height: 100%;
          border: none;
          display: block;
          background: #fff;
        }

        /* ── Start / Home page ── */
        .start-page {
          flex: 1;
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          padding: 40px 24px;
          overflow-y: auto;
          gap: 0;
        }

        .start-icon {
          margin-bottom: 28px;
          opacity: 0.92;
          filter: drop-shadow(0 0 24px rgba(139,92,246,0.35));
          animation: float 4s ease-in-out infinite;
        }
        @keyframes float {
          0%, 100% { transform: translateY(0); }
          50%       { transform: translateY(-6px); }
        }

        .start-title {
          font-size: 28px;
          font-weight: 300;
          color: var(--text);
          letter-spacing: -0.02em;
          margin-bottom: 8px;
          text-align: center;
        }
        .start-title span {
          font-weight: 600;
          color: var(--accent);
        }

        .start-sub {
          font-size: 14px;
          color: var(--muted);
          margin-bottom: 40px;
          text-align: center;
          max-width: 420px;
          line-height: 1.6;
        }

        .privacy-cards {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
          gap: 12px;
          width: 100%;
          max-width: 700px;
          margin-bottom: 40px;
        }

        .privacy-card {
          background: var(--surface);
          border: 1px solid var(--border);
          border-radius: 12px;
          padding: 16px 18px;
          font-size: 13px;
          color: var(--muted);
          line-height: 1.55;
          display: flex;
          gap: 12px;
          align-items: flex-start;
          transition: border-color 0.2s, background 0.2s;
        }
        .privacy-card:hover {
          border-color: var(--accent-dim);
          background: var(--surface2);
        }
        .privacy-card-dot {
          width: 6px;
          height: 6px;
          border-radius: 50%;
          background: var(--accent);
          margin-top: 5px;
          flex-shrink: 0;
          box-shadow: 0 0 8px var(--accent);
        }

        .quick-links {
          display: flex;
          gap: 10px;
          flex-wrap: wrap;
          justify-content: center;
        }
        .quick-link {
          padding: 8px 18px;
          border-radius: 20px;
          border: 1px solid var(--border);
          background: var(--surface);
          color: var(--muted);
          font-size: 13px;
          cursor: pointer;
          transition: all 0.15s;
          font-family: var(--mono);
        }
        .quick-link:hover {
          border-color: var(--accent);
          color: var(--accent);
          background: var(--accent-glow);
        }

        /* ── Error state ── */
        .error-overlay {
          position: absolute;
          inset: 0;
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          gap: 12px;
          background: var(--bg);
          color: var(--muted);
          font-size: 14px;
          text-align: center;
          padding: 24px;
        }
        .error-title {
          color: var(--danger);
          font-size: 16px;
          font-weight: 500;
        }
        .error-hint {
          font-family: var(--mono);
          font-size: 12px;
          color: var(--border);
          background: var(--surface);
          padding: 8px 14px;
          border-radius: 6px;
          border: 1px solid var(--border);
        }
      `}</style>

      <div className="browser-shell">
        {/* ── Toolbar ── */}
        <div className="toolbar">
          <button
            className="nav-btn"
            onClick={() => iframeRef.current?.contentWindow?.history.back()}
            disabled={!isPrivate}
            title="Back"
          >
            <BackIcon />
          </button>
          <button
            className="nav-btn"
            onClick={() => iframeRef.current?.contentWindow?.history.forward()}
            disabled={!isPrivate}
            title="Forward"
          >
            <ForwardIcon />
          </button>
          <button
            className="nav-btn"
            onClick={isPrivate ? handleRefresh : null}
            disabled={!isPrivate}
            title="Reload"
          >
            <RefreshIcon />
          </button>
          <button
            className="nav-btn"
            onClick={handleHome}
            title="Home"
          >
            <HomeIcon />
          </button>

          <form className="url-form" onSubmit={handleSubmit}>
            {isPrivate && <LockIcon />}
            <input
              ref={inputRef}
              className="url-input"
              type="text"
              value={inputUrl}
              onChange={e => setInputUrl(e.target.value)}
              placeholder="Enter URL or search term..."
              spellCheck={false}
              autoComplete="off"
              autoCorrect="off"
            />
          </form>

          <div className="private-badge">
            <ShieldIcon />
            PRIVATE
          </div>
        </div>

        {/* ── Loading indicator ── */}
        <div className={`progress-bar${loading ? ' loading' : ''}`} />

        {/* ── Main area ── */}
        {isPrivate ? (
          <div className="viewport">
            <iframe
              ref={iframeRef}
              key={iframeSrc}
              src={iframeSrc}
              className="proxy-iframe"
              title="Private browsing viewport"
              sandbox="allow-scripts allow-same-origin allow-forms allow-popups allow-popups-to-escape-sandbox"
              onLoad={() => setLoading(false)}
              onError={() => {
                setLoading(false);
                setError('Page failed to load. The site may block proxying.');
              }}
            />
            {error && (
              <div className="error-overlay">
                <span className="error-title">⚠ Could not load page</span>
                <p>{error}</p>
                <span className="error-hint">{displayUrl}</span>
                <button
                  onClick={() => { setError(''); handleHome(); }}
                  style={{
                    padding: '8px 20px',
                    borderRadius: '8px',
                    border: '1px solid var(--accent)',
                    background: 'var(--accent-glow)',
                    color: 'var(--accent)',
                    cursor: 'pointer',
                    fontSize: '13px',
                  }}
                >
                  Back to home
                </button>
              </div>
            )}
          </div>
        ) : (
          <div className="start-page">
            <div className="start-icon">
              <IncognitoIcon size={90} />
            </div>

            <h1 className="start-title">
              You're <span>privately</span> browsing
            </h1>
            <p className="start-sub">
              Every request is fetched server-side. Your IP, browser fingerprint,
              and identity stay hidden from the sites you visit.
            </p>

            <div className="privacy-cards">
              {PRIVACY_BULLETS.map((b, i) => (
                <div className="privacy-card" key={i}>
                  <span className="privacy-card-dot" />
                  <span>{b}</span>
                </div>
              ))}
            </div>

            <div className="quick-links">
              {[
                ['DuckDuckGo', 'https://duckduckgo.com'],
                ['Wikipedia', 'https://en.wikipedia.org'],
                ['Hacker News', 'https://news.ycombinator.com'],
                ['GitHub', 'https://github.com'],
              ].map(([label, url]) => (
                <button
                  key={label}
                  className="quick-link"
                  onClick={() => navigate(url)}
                >
                  {label}
                </button>
              ))}
            </div>
          </div>
        )}
      </div>
    </>
  );
}
