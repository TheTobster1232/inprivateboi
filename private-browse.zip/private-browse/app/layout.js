import './globals.css';

export const metadata = {
  title: 'Private Browse',
  description: 'Server-side private browsing proxy — no history, no cookies, no trace.',
  icons: {
    icon: 'data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 100 100%22><text y=%22.9em%22 font-size=%2290%22>🕵️</text></svg>',
  },
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        {/* Fonts loaded via CSS @import so they don't block the Next.js build */}
      </head>
      <body>{children}</body>
    </html>
  );
}
